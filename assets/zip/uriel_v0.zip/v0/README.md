# URIEL Typological Compendium

This directory represents the result data from the initial URIEL Typological Compendium release (v0).

## FEATURES:

All files listed here have a simple tabular format, in CSV format, with ISO 639-3 language identifiers in the first column, and features at the top.  Features starting with G_ are in various formats; all other features are [0.0,1.0] intervals.

For example, the file might look something like:

G_CODE, S_SUBJECT_BEFORE_VERB, S_SUBJECT_AFTER_VERB
deu, 1.0, 0.0
eng, 1.0, 0.0

These files are directly deduced from three feature databases.  Each source is given as its own CSV file.

**wals.csv** -- Features derived from the World Atlas of Language Structures
**sswl.csv** -- Features derived from Syntactic Structures of the World's Languages
**phoible.csv** -- Features derived from PHOIBLE

For this release, treat information like the "name" of the language as being for internal reference only; they do not represent every possible name associated with an ISO 639-3 code.  To discover a language's code, look it up in Ethnologue instead.

## DISTANCES:

The distance files represent "driving distance" charts between two languages, for various metrics (e.g., phylogenetic distance), with 0.0 representing identity and 1.0 being as far apart as two languages can be.

code, deu, eng, swe, jpn
deu, 0.0, 0.4, 0.6, 1.0
eng, 0.4, 0.0, 0.6, 1.0
swe, 0.6, 0.6, 0.0, 1.0
jpn, 1.0, 1.0, 1.0, 0.0

We also provide, for convenience, pre-sorted rank-ordered charts, listing the 1st, 2nd, 3rd, etc. closest languages to the given language.  E.g.:

code, 1, 2, 3
deu, eng, swe, jpn
eng, deu, swe, jpn
swe, deu, eng, jpn
jpn, deu, swe, eng

Five charts are provided:

**genetic_distance.csv** -- A distance metric derived from the Ethnologue hypothesized tree of language, representing the number of steps upward on the tree until the two languages are unified under a single node, divided by the number of branches in between L1 and the root.  (In other words, the percentage of L1's descent not shared by L2.)  This has the advantage of correctly sorting languages by relation even in a tree with wildly different levels of detail between branches and families.  The downside is that this relationship is not commutative, and the numbers do not have any absolute significance.  (E.g., that L1 and L2 are related by "0.4" is not meaningful except in comparison with other relatives of L1;

**geo_distance.csv** -- The orthodromic ("great circle") distance between the languages on the surface of the earth, divided by the antipodal distance (i.e., diameter/2).

**composite_distance.csv** -- A weighted composite of the values in the two charts above, with genetic distance outweighing geodistance 100 to 1.  This biases the metric towards geographically-closer languages when languages are otherwise equally-related, but never biases a nearby language so much that it is ranked before a more closely-related language.  (Taking English as an example, by pure genetic distance French and Hindi are equally distant from English; this measure adds a geographical bias so that French ranks slightly closer than Hindi.  This bias will not, however, end up ranking either before German.)

**s_distance.csv** -- The distance between the vectors defined by the S_ (syntactic) features in the database, as defined as the arccosine of the dot product of the normalized vectors.  Note as a crucial caveat that this measure is less meaningful the less is known about the language within the database.  From the point of view of this measure, the most similar language to a language about which we know basically nothing is another language about which we know basically nothing!

**p_distance.csv** -- The same as in s_distance, but with vectors defined by the P_ (phonological) features in the database.

## DERIVED FEATURES

We also provide calculated sources, including consensus values (like averages) and predicted values (such as kNN regressions based on phylogenetic or geographical neighbors).

These feature charts are in the same format as the feature charts above, e.g.:

G_CODE, S_SUBJECT_BEFORE_VERB, S_SUBJECT_AFTER_VERB
deu, 1.0, 0.0
eng, 1.0, 0.0

**avg.csv** -- A simple mean of (known) values in the above sources.  That is to say, it is the probability of a feature being 1.0 if a source is chosen at random.

**gene_5.csv** -- A five-nearest-neighbors regression of avg.csv, using the distances in genenic_distance.csv below.

**geo_5.csv** -- A five-nearest-neighbors regression of avg.csv, using the distances in geo_distance.csv below.

# REFERENCES

-- 2015. CLDR—Unicode Common Locale Data. Mountain View, CA: Unicode Consortium. (Available online at http://cldr.unicode.org/, accessed on 2015-11-05)

-- 2015. ScriptSource. Dallas: SIL International. (Available online at http://scriptsource.org, accessed on 2015-11-05.)
Collins, Chris & Kayne, Richard(eds.) 2011. Syntactic Structures of the World’s Languages. New York: New York University. (Available online at http://sswl.railsplayground.net, Accessed on 2015-11-05.)

Dryer, Matthew S. & Haspelmath, Martin (eds.) 2013. The World Atlas of Language Structures Online. Leipzig: Max Planck Institute for Evolutionary Anthropology. (Available online at http://wals.info, Accessed on 2015-11-05.)

Hammarström, Harald & Forkel, Robert & Haspelmath, Martin & Bank, Sebastian. 2015. Glottolog 2.6. Jena: Max Planck Institute for the Science of Human History. (Available online at http://glottolog.org, Accessed on 2015-11-06.)

Lewis, M. Paul (ed.), 2009. Ethnologue: Languages of the World, Sixteenth edition. Dallas, Texas: SIL International. Online version: http://www.ethnologue.com/16.

Moran, Steven & McCloy, Daniel & Wright, Richard (eds.) 2014. PHOIBLE Online. Leipzig: Max Planck Institute for Evolutionary Anthropology. (Available online at http://phoible.org, Accessed on 2015-11-05.)
